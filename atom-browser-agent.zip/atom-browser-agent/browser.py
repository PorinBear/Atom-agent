from pathlib import Path
from playwright.sync_api import sync_playwright

SELECTABLE = "a,button,input,textarea,select,[role=button],[contenteditable=true]"

class BrowserController:
    def __init__(self, config: dict):
        self.config = config
        self.pw = None
        self.context = None
        self.page = None

    def start(self):
        profile = Path(self.config["profile_dir"]).resolve()
        downloads = Path(self.config["downloads_dir"]).resolve()
        profile.mkdir(parents=True, exist_ok=True)
        downloads.mkdir(parents=True, exist_ok=True)

        self.pw = sync_playwright().start()
        self.context = self.pw.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=self.config.get("headless", False),
            accept_downloads=True,
            viewport=self.config.get("viewport", {"width": 1440, "height": 1000}),
            downloads_path=str(downloads),
        )
        self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
        self.page.set_default_timeout(12000)

    def stop(self):
        try:
            if self.context:
                self.context.close()
        finally:
            if self.pw:
                self.pw.stop()

    def read_page(self):
        body = self.page.locator("body").inner_text(timeout=10000)[:18000]
        elements = self.page.locator(SELECTABLE)
        items = []
        for i in range(min(elements.count(), 120)):
            el = elements.nth(i)
            try:
                tag = el.evaluate("(e)=>e.tagName.toLowerCase()")
                text = (el.inner_text() or "").strip()[:180]
                aria = (el.get_attribute("aria-label") or "")[:120]
                name = (el.get_attribute("name") or "")[:120]
                placeholder = (el.get_attribute("placeholder") or "")[:120]
                href = (el.get_attribute("href") or "")[:220]
                typ = (el.get_attribute("type") or "")[:60]
                items.append({
                    "i": i, "tag": tag, "text": text, "aria": aria,
                    "name": name, "placeholder": placeholder,
                    "href": href, "type": typ
                })
            except Exception:
                pass
        return {
            "title": self.page.title(),
            "url": self.page.url,
            "body": body,
            "elements": items
        }

    def _loc(self, action):
        if action.get("selector"):
            return self.page.locator(action["selector"]).first
        return self.page.locator(SELECTABLE).nth(int(action["index"]))

    def execute(self, action: dict):
        name = action.get("action")

        if name == "goto":
            self.page.goto(action["url"], wait_until="domcontentloaded")
            return {"url": self.page.url, "title": self.page.title()}

        if name == "click":
            self._loc(action).click()
            return {"ok": True}

        if name == "type":
            loc = self._loc(action)
            if action.get("clear", True):
                loc.fill(action.get("text", ""))
            else:
                loc.type(action.get("text", ""))
            return {"ok": True}

        if name == "press":
            self._loc(action).press(action.get("key", "Enter"))
            return {"ok": True}

        if name == "scroll":
            self.page.mouse.wheel(0, int(action.get("amount", 700)))
            return {"ok": True}

        if name == "wait":
            self.page.wait_for_timeout(int(action.get("ms", 1000)))
            return {"ok": True}

        if name == "screenshot":
            path = action.get("path", "logs/latest.png")
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            self.page.screenshot(path=path, full_page=False)
            return {"path": path}

        if name == "read":
            return self.read_page()

        raise ValueError(f"Tuntematon toiminto: {name}")

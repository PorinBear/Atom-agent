import json
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

from browser import BrowserController
from planner import Planner
from approvals import requires_approval, ask_approval
from logger import AgentLogger

def load_config():
    cfg = json.loads(Path("config.json").read_text(encoding="utf-8"))
    if os.getenv("ATOM_HEADLESS"):
        cfg["headless"] = os.getenv("ATOM_HEADLESS", "false").lower() == "true"
    if os.getenv("ATOM_MAX_STEPS"):
        cfg["max_steps"] = int(os.getenv("ATOM_MAX_STEPS"))
    return cfg

def main():
    load_dotenv()

    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit(
            "OPENAI_API_KEY puuttuu. Kopioi .env.example tiedostoksi .env ja lisää API-avain."
        )

    task = " ".join(sys.argv[1:]).strip()
    if not task:
        task = input("ATOM tehtävä> ").strip()
    if not task:
        raise SystemExit("Tehtävä puuttuu.")

    config = load_config()
    model = os.getenv("OPENAI_MODEL", "gpt-5.6")
    browser = BrowserController(config)
    planner = Planner(model)
    logger = AgentLogger(config["logs_dir"])
    history = []

    try:
        browser.start()
        start_url = config.get("start_url")
        if start_url:
            try:
                browser.execute({"action": "goto", "url": start_url})
            except Exception:
                pass

        print(f"\nATOM käynnissä — {task}\n")

        for step in range(1, int(config["max_steps"]) + 1):
            state = browser.read_page()
            print(f"[{step}] {state['title']} — {state['url']}")

            action = planner.next_action(task, state, history)
            logger.write({"step": step, "action": action})
            print(" →", action.get("action"), action.get("reason", ""))

            if action.get("action") == "done":
                summary = action.get("summary", "Valmis.")
                print("\n✅", summary)
                logger.write({"step": step, "done": summary})
                return

            if requires_approval(action) and not ask_approval(action):
                result = {"status": "user_denied"}
            else:
                try:
                    result = browser.execute(action)
                except Exception as exc:
                    result = {"error": f"{type(exc).__name__}: {exc}"}

            history.append({"action": action, "result": result})
            logger.write({"step": step, "result": result})

        print("\n⚠️ Maksimivaihemäärä saavutettu.")
    finally:
        browser.stop()

if __name__ == "__main__":
    main()

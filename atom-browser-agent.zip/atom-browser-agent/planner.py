import json
from openai import OpenAI

SYSTEM_PROMPT = """
You are ATOM, a careful browser work agent.

You receive the user's task, the current web page state, and recent history.
Choose exactly ONE next action.

Allowed JSON actions:
{"action":"goto","url":"https://...","reason":"..."}
{"action":"click","index":12,"reason":"..."}
{"action":"type","index":4,"text":"...","clear":true,"reason":"..."}
{"action":"press","index":4,"key":"Enter","reason":"..."}
{"action":"scroll","amount":700,"reason":"..."}
{"action":"wait","ms":1000,"reason":"..."}
{"action":"screenshot","path":"logs/latest.png","reason":"..."}
{"action":"read","reason":"..."}
{"action":"done","summary":"..."}

Rules:
- Output JSON only.
- Never invent an element index not present in page_state.
- Prefer element indexes.
- Never bypass CAPTCHA, authentication, access control, paywalls, or security controls.
- If login or MFA requires a human, return done and explain manual login is required.
- Avoid destructive or irreversible actions unless explicitly requested.
- If the task is complete, use done.
"""

class Planner:
    def __init__(self, model: str):
        self.client = OpenAI()
        self.model = model

    def next_action(self, task: str, page_state: dict, history: list[dict]) -> dict:
        payload = {
            "task": task,
            "page_state": page_state,
            "recent_history": history[-8:]
        }

        response = self.client.responses.create(
            model=self.model,
            input=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False)}
            ]
        )

        raw = response.output_text.strip()
        if raw.startswith("```"):
            raw = raw.replace("```json", "", 1).replace("```", "").strip()
        return json.loads(raw)

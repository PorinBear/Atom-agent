# ATOM Browser Agent

Ensimmäinen toimiva selainagentti: Python + Playwright + OpenAI.

## Ominaisuudet
- näkyvä Chromium-selain
- pysyvä selainprofiili kirjautumisia varten
- URL-navigointi
- sivun tekstin ja käyttöelementtien lukeminen
- klikkaaminen
- kenttiin kirjoittaminen
- näppäinpainallukset
- vieritys
- kuvakaappaukset
- JSONL-loki
- hyväksyntäraja riskitoimille

## Windows-asennus

1. Pura ZIP.
2. Avaa PowerShell projektikansioon.
3. Suorita:

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
copy .env.example .env
```

4. Avaa `.env` ja lisää OpenAI API -avain.

5. Käynnistä:

```powershell
python agent.py
```

Tai anna tehtävä suoraan:

```powershell
python agent.py "Avaa example.com ja kerro mitä sivulla on"
```

## Kirjautuminen

Selain käyttää `browser-profile`-kansiota. Kirjaudu palveluihin itse ensimmäisellä kerralla.
Älä laita salasanoja lähdekoodiin tai tehtävätekstiin.

## Turva

Maksut, ostot, pankkitoimet, sopimuksen hyväksyminen, tilien poistaminen ja vastaavat
toimet pyytävät erillisen hyväksynnän.

## Seuraava kehitysaskel

- tiedostojen upload/download-tunnistus
- visuaalinen screenshot-analyysi
- tehtäväjono
- sähköposti- ja kalenterityöntekijät
- käyttöliittymä
- monen agentin työnjako

RISK_TERMS = [
    "pay", "payment", "purchase", "buy now", "place order",
    "bank transfer", "wire transfer", "send money",
    "delete account", "remove account", "cancel subscription",
    "accept contract", "sign contract", "confirm purchase",
    "maksa", "maksu", "osta", "tilaa", "pankkisiirto",
    "poista käyttäjä", "poista tili", "irtisano", "hyväksy sopimus"
]

def requires_approval(action: dict) -> bool:
    blob = " ".join(str(v) for v in action.values()).lower()
    return any(term in blob for term in RISK_TERMS)

def ask_approval(action: dict) -> bool:
    print("\n⚠️ Hyväksyntä vaaditaan:")
    print(action)
    ans = input("Suoritetaanko? [y/N]: ").strip().lower()
    return ans in ("y", "yes", "j", "jaa", "kyllä", "kylla")
